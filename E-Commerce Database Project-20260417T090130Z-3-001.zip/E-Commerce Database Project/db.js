const oracledb = require('oracledb');

// Configure Oracle DB connection details.
// Make sure these match your local SQL*Plus credentials.
const dbConfig = {
    user: process.env.NODE_ORACLEDB_USER || "system", // Try replacing "system" with your Oracle user
    password: process.env.NODE_ORACLEDB_PASSWORD || "student", // Put your Oracle DB password here
    connectString: process.env.NODE_ORACLEDB_CONNECTIONSTRING || "localhost/XE" // Change "XE" to your DB SID/Service Name if different
};

async function executeQuery(query, binds = [], opts = { outFormat: oracledb.OUT_FORMAT_OBJECT, autoCommit: true }) {
    let connection;
    try {
        connection = await oracledb.getConnection(dbConfig);
        const result = await connection.execute(query, binds, opts);
        return result;
    } catch (err) {
        console.error('Database Error:', err);
        throw err;
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error('Error closing connection:', err);
            }
        }
    }
}

module.exports = { executeQuery };
