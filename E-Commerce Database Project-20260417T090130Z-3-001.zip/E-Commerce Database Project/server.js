const express = require('express');
const cors = require('cors');
const { executeQuery } = require('./db');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const ALLOWED_TABLES = ['BUYER', 'EMPLOYEE', 'MANAGES', 'PRODUCT', 'PURCHASES', 'SELLER', 'TRANSACTION'];

// GET all schema details for forms dynamically
app.get('/api/schema/:table', async (req, res) => {
    const table = req.params.table.toUpperCase();
    if (!ALLOWED_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });

    try {
        const query = `
            SELECT column_name, data_type, data_length
            FROM user_tab_columns
            WHERE table_name = :table_name
            ORDER BY column_id
        `;
        const result = await executeQuery(query, [table]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET foreign key options (simplification: returning all IDs from a parent table)
app.get('/api/lookup/:parentTable', async (req, res) => {
    const parentTable = req.params.parentTable.toUpperCase();
    if (!ALLOWED_TABLES.includes(parentTable)) return res.status(400).json({ error: 'Invalid table' });

    // Identify primary key column of the parent table
    // For simplicity, we just infer from table name
    let pkCol = parentTable === 'TRANSACTION' ? 'TXNID' : 
                parentTable === 'PRODUCT' ? 'PRODUCTID' : 
                parentTable === 'BUYER' ? 'BUYERID' : 
                parentTable === 'SELLER' ? 'SELLERID' : 
                parentTable === 'EMPLOYEE' ? 'EMPID' : null;

    if (!pkCol) return res.status(400).json({ error: 'Lookup not supported for this table' });

    try {
        const query = `SELECT ${pkCol} AS ID FROM ${parentTable}`;
        const result = await executeQuery(query);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET all records from a table
app.get('/api/:table', async (req, res) => {
    const table = req.params.table.toUpperCase();
    if (!ALLOWED_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });

    try {
        const query = `SELECT * FROM ${table}`;
        const result = await executeQuery(query);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST to insert a new record
app.post('/api/:table', async (req, res) => {
    const table = req.params.table.toUpperCase();
    if (!ALLOWED_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });

    const data = req.body; 
    const columns = Object.keys(data);
    
    // Map array binds and convert date strings (YYYY-MM-DD) into Date objects
    const binds = Object.values(data).map(val => {
        if (typeof val === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(val)) {
            return new Date(val);
        }
        return val;
    });
    
    const placeholders = columns.map((_, i) => `:${i+1}`).join(", ");
    
    try {
        const query = `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders})`;
        const result = await executeQuery(query, binds);
        res.json({ success: true, rowsAffected: result.rowsAffected });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE a record using an object of primary keys
app.delete('/api/:table', async (req, res) => {
    const table = req.params.table.toUpperCase();
    if (!ALLOWED_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });

    const keys = req.body; 
    if (!keys || Object.keys(keys).length === 0) {
        return res.status(400).json({ error: 'No keys provided for deletion' });
    }

    const conditions = [];
    const binds = [];
    let i = 1;

    for (const [col, val] of Object.entries(keys)) {
        conditions.push(`${col} = :${i}`);
        // Support Date parsing for composite keys that might include dates (like MANAGES or PURCHASES)
        if (typeof val === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(val)) {
            binds.push(new Date(val));
        } else {
            binds.push(val);
        }
        i++;
    }

    try {
        const query = `DELETE FROM ${table} WHERE ${conditions.join(' AND ')}`;
        const result = await executeQuery(query, binds);
        res.json({ success: true, rowsAffected: result.rowsAffected });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
