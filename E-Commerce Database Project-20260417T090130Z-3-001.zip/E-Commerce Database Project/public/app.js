document.addEventListener('DOMContentLoaded', () => {
    const tableButtons = document.querySelectorAll('#table-list button');
    const tableHead = document.getElementById('table-head');
    const tableBody = document.getElementById('table-body');
    const emptyState = document.getElementById('no-data');
    const loader = document.getElementById('loading');
    const searchInput = document.getElementById('search-input');
    const addRecordBtn = document.getElementById('add-record-btn');
    const currentTableTitle = document.getElementById('current-table-title');
    
    // Modal elements
    const modalOverlay = document.getElementById('add-modal');
    const closeModalBtn = document.getElementById('close-modal');
    const addForm = document.getElementById('add-form');
    const formFieldsContainer = document.getElementById('form-fields');

    let currentTable = '';
    let currentSchema = [];
    let currentData = [];

    // Table Selection Logic
    tableButtons.forEach(btn => {
        btn.addEventListener('click', async () => {
            tableButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            currentTable = btn.getAttribute('data-table');
            currentTableTitle.textContent = currentTable;
            addRecordBtn.style.display = 'inline-flex';
            searchInput.value = '';
            
            await loadTableData(currentTable);
        });
    });

    // Fetch Table Schema and Data
    async function loadTableData(tableName) {
        showLoader();
        try {
            // Fetch Schema first
            const schemaRes = await fetch(`/api/schema/${tableName}`);
            currentSchema = await schemaRes.json();
            
            // Fetch Data
            const dataRes = await fetch(`/api/${tableName}`);
            const data = await dataRes.json();
            currentData = data;
            
            renderTable(currentData);
        } catch (error) {
            console.error('Error loading data:', error);
            alert('Failed to connect to database. Is the backend running?');
        } finally {
            hideLoader();
        }
    }

    function renderTable(dataToRender) {
        tableHead.innerHTML = '';
        tableBody.innerHTML = '';
        
        if (!currentSchema || currentSchema.length === 0) {
            emptyState.style.display = 'flex';
            return;
        }

        // Handle empty table but with schema
        if (dataToRender.length === 0) {
            emptyState.style.display = 'flex';
            emptyState.querySelector('p').textContent = 'No records found in ' + currentTable;
        } else {
            emptyState.style.display = 'none';
        }

        // Render Headers
        const headerRow = document.createElement('tr');
        currentSchema.forEach(col => {
            const th = document.createElement('th');
            th.textContent = col.COLUMN_NAME || col.column_name;
            headerRow.appendChild(th);
        });
        const actionsTh = document.createElement('th');
        actionsTh.textContent = 'Actions';
        headerRow.appendChild(actionsTh);
        tableHead.appendChild(headerRow);

        // Render Rows
        dataToRender.forEach(row => {
            const tr = document.createElement('tr');
            currentSchema.forEach(col => {
                const colName = col.COLUMN_NAME || col.column_name;
                const td = document.createElement('td');
                // Format dates safely
                let cellData = row[colName] !== undefined ? row[colName] : row[colName.toLowerCase()];
                if (colName.includes('DATE') && cellData) cellData = new Date(cellData).toLocaleDateString();
                td.textContent = cellData;
                tr.appendChild(td);
            });
            
            // Actions
            const actionsTd = document.createElement('td');
            const delBtn = document.createElement('button');
            delBtn.className = 'btn btn-danger';
            delBtn.innerHTML = '<ion-icon name="trash-outline"></ion-icon> Delete';
            delBtn.onclick = () => handleDelete(row);
            actionsTd.appendChild(delBtn);
            tr.appendChild(actionsTd);
            
            tableBody.appendChild(tr);
        });
    }

    // Delete Record Implementation
    async function handleDelete(rowData) {
        if(!confirm('Are you sure you want to delete this record?')) return;
        
        // Identify primary key based on table to send for deletion
        let pkColumns = [];
        if (currentTable === 'PURCHASES') pkColumns = ['BUYERID', 'PRODUCTID'];
        else if (currentTable === 'MANAGES') pkColumns = ['SELLERID', 'EMPID'];
        else if (currentTable === 'TRANSACTION') pkColumns = ['TXNID'];
        else if (currentTable === 'PRODUCT') pkColumns = ['PRODUCTID'];
        else if (currentTable === 'SELLER') pkColumns = ['SELLERID'];
        else if (currentTable === 'BUYER') pkColumns = ['BUYERID'];
        else if (currentTable === 'EMPLOYEE') pkColumns = ['EMPID'];
        
        const payload = {};
        pkColumns.forEach(col => {
            payload[col] = rowData[col] !== undefined ? rowData[col] : rowData[col.toLowerCase()];
        });

        try {
            const res = await fetch(`/api/${currentTable}`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if(res.ok) {
                // Refresh data
                await loadTableData(currentTable);
            } else {
                const err = await res.json();
                alert('Error deleting: ' + (err.error || 'Unknown error'));
            }
        } catch(error) {
            console.error(error);
        }
    }

    // Client-side Filter
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        if(!currentData.length) return;
        if(query.trim() === '') {
            renderTable(currentData);
            return;
        }
        const filtered = currentData.filter(row => {
            return Object.values(row).some(val => 
                String(val).toLowerCase().includes(query)
            );
        });
        renderTable(filtered);
    });

    // Form / Modal Logic
    addRecordBtn.addEventListener('click', async () => {
        await buildForm();
        modalOverlay.classList.add('active');
    });

    closeModalBtn.addEventListener('click', () => {
        modalOverlay.classList.remove('active');
    });

    // Close on completely outside click
    modalOverlay.addEventListener('click', (e) => {
        if(e.target === modalOverlay) modalOverlay.classList.remove('active');
    });

    addForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(addForm);
        const dataObj = {};
        
        currentSchema.forEach(col => {
            const colName = col.COLUMN_NAME || col.column_name;
            const val = formData.get(colName);
            // Handle number conversions simply or let API handle relying on Oracle's implicit casts
            dataObj[colName] = val;
        });

        try {
            const res = await fetch(`/api/${currentTable}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(dataObj)
            });
            
            if(res.ok) {
                modalOverlay.classList.remove('active');
                await loadTableData(currentTable);
            } else {
                const err = await res.json();
                alert('Error inserting: ' + (err.error || 'Check Constraints/Types'));
            }
        } catch(error) {
            console.error(error);
        }
    });

    async function buildForm() {
        formFieldsContainer.innerHTML = '';
        
        for(let col of currentSchema) {
            const colName = col.COLUMN_NAME || col.column_name;
            const dataType = col.DATA_TYPE || col.data_type;
            
            const group = document.createElement('div');
            group.className = 'form-group';
            
            const label = document.createElement('label');
            label.textContent = colName;
            group.appendChild(label);

            // Heuristic for Foreign Keys based on Schema naming conventions
            const primaryKeys = {
                'TRANSACTION': ['TXNID'],
                'EMPLOYEE': ['EMPID'],
                'SELLER': ['SELLERID'],
                'BUYER': ['BUYERID'],
                'PRODUCT': ['PRODUCTID'],
                'PURCHASES': [], // Let composite PKs act as FK dropdowns
                'MANAGES': []    // Let composite PKs act as FK dropdowns
            };
            const tablePKs = primaryKeys[currentTable] || [];
            const isFK = colName.endsWith('ID') && !tablePKs.includes(colName);
            
            if(isFK) {
                let parentTableKey = colName.replace('ID', ''); // BUYER
                if (parentTableKey === 'EMP') parentTableKey = 'EMPLOYEE';
                if (parentTableKey === 'TXN') parentTableKey = 'TRANSACTION';

                const select = document.createElement('select');
                select.name = colName;
                select.required = true;
                
                try {
                    // Fetch lookup values
                    const lookupRes = await fetch(`/api/lookup/${parentTableKey}`);
                    const lookupData = await lookupRes.json();
                    
                    if(lookupData && lookupData.length) {
                        lookupData.forEach(item => {
                            const opt = document.createElement('option');
                            const idVal = item.ID || item.id;
                            opt.value = idVal;
                            opt.textContent = idVal;
                            select.appendChild(opt);
                        });
                    } else {
                        const opt = document.createElement('option');
                        opt.textContent = 'No values available';
                        select.appendChild(opt);
                    }
                } catch(err) {
                    const opt = document.createElement('option');
                    opt.textContent = 'Failed to load options';
                    select.appendChild(opt);
                }
                group.appendChild(select);
            } else {
                const input = document.createElement('input');
                input.name = colName;
                input.required = true;
                
                if (dataType === 'DATE') {
                    input.type = 'date';
                } else if (dataType === 'NUMBER') {
                    input.type = 'number';
                    input.step = 'any';
                } else {
                    input.type = 'text';
                }
                
                group.appendChild(input);
            }
            formFieldsContainer.appendChild(group);
        }
    }

    function showLoader() {
        loader.style.display = 'block';
        tableBody.style.opacity = '0.5';
    }

    function hideLoader() {
        loader.style.display = 'none';
        tableBody.style.opacity = '1';
    }
});
